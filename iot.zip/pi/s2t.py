#Python 2.x program for Speech Recognition 
  
import speech_recognition as sr 
import pyttsx3
import requests
import time

def SpeakText(command): 
      
    # Initialize the engine 
    engine = pyttsx3.init() 
    engine.say(command)  
    engine.runAndWait() 
    
#enter the name of usb microphone that you found 
#using lsusb 
#the following name is only used as an example 
mic_name = "device 0: ALC3227 Analog [ALC3227 Analog]"
#Sample rate is how often values are recorded 
sample_rate = 48000
#Chunk is like a buffer. It stores 2048 samples (bytes of data) 
#here.  
#it is advisable to use powers of 2 such as 1024 or 2048 
chunk_size = 2048
#Initialize the recognizer 
r = sr.Recognizer() 
  
#generate a list of all audio cards/microphones 
mic_list = sr.Microphone.list_microphone_names() 
  
#the following loop aims to set the device ID of the mic that 
#we specifically want to use to avoid ambiguity. 

device_id = 0
  
#use the microphone as source for input. Here, we also specify  
#which device ID to specifically look for incase the microphone  
#is not working, an error will pop up saying "device_id undefined" 
with sr.Microphone(device_index = device_id, sample_rate = sample_rate,  
                        chunk_size = chunk_size) as source: 
    #wait for a second to let the recognizer adjust the  
    #energy threshold based on the surrounding noise level 
    
    SpeakText('Hai... Am Siri.. ')
    print ("Siri Hearing")
    #listens for the user's input 
    while(1): 
        try:
            print(source)
            audio = r.listen(source) 
            print('1')
            text = r.recognize_google(audio)
            print(text)
            if(text=='hey Siri'): 
                time.sleep(1)
                SpeakText('Yes i am listening')
                audio = r.listen(source) 
                text = r.recognize_google(audio)
                text.lower()
                print(text)
                response = requests.get("https://iothome.tk/update.php?command="+text)
                data = response.text;
                print (data )
                if(data =='No Command Found'):
                    SpeakText('Sorry that was an invalid command.. Try again')
                if(data =='Success'):
                    SpeakText('Successfully activated') 
                time.sleep(1)
            #error occurs when google could not understand what was said 
          
        except sr.UnknownValueError: 
                print("Google Speech Recognition could not understand audio") 
              
        except sr.RequestError as e: 
                print("Could not request results from Google Speech Recognition service; {0}".format(e)) 
